import React from 'react';
import {
  HiBriefcase,
  HiAcademicCap,
  HiFolder,
  HiSparkles,
  HiLanguage,
  HiUserGroup,
} from 'react-icons/hi2';

import {
  TwoPageResumeCanvas,
  PageRunningHeader,
  SectionTitle,
  ExperienceItem,
  ProjectCard,
  EducationItem,
  SummaryCard,
  ContactList,
} from './engine/LayoutEngine.jsx';

import { getTemplateTypography } from '../../config/resumeTypography.js';
import { normalizeResumeSections } from './utils/normalizeResumeSections.js';
import { withPlaceholder } from './utils/placeholderData.js';

function ExecutiveCorporateTemplate({ sections, colors, isPreview = false }) {
  const normalizedSections = normalizeResumeSections(sections || {});
  const personalInfo = withPlaceholder('personalInfo', normalizedSections.personalInfo, normalizedSections, isPreview);
  const summary = withPlaceholder('summary', normalizedSections.summary, normalizedSections, isPreview);
  const experience = withPlaceholder('experience', normalizedSections.experience, normalizedSections, isPreview);
  const education = withPlaceholder('education', normalizedSections.education, normalizedSections, isPreview);
  const skills = withPlaceholder('skills', normalizedSections.skills, normalizedSections, isPreview);
  const projects = withPlaceholder('projects', normalizedSections.projects, normalizedSections, isPreview);
  const certifications = withPlaceholder('certifications', normalizedSections.certifications, normalizedSections, isPreview);

  const primaryColor = colors?.primary || '#1e1b4b';
  const accentColor = colors?.accent || '#d97706';

  const rawTech = [
    ...(Array.isArray(skills.technical) ? skills.technical : []),
    ...(Array.isArray(skills.tools) ? skills.tools : []),
    ...(Array.isArray(skills.frameworks) ? skills.frameworks : []),
    ...(Array.isArray(skills.databases) ? skills.databases : []),
    ...(Array.isArray(skills.libraries) ? skills.libraries : []),
  ];
  const techSkills = [...new Set(rawTech.map((s) => (typeof s === 'string' ? s.trim() : String(s || '').trim())).filter(Boolean))];

  const rawSoft = Array.isArray(skills.soft) ? skills.soft : [];
  const softSkills = [...new Set(rawSoft.map((s) => (typeof s === 'string' ? s.trim() : String(s || '').trim())).filter(Boolean))];

  const languages = (skills.languages || []).filter((l) => l && typeof l === 'string' && l.trim());

  const validEducation = (education || []).filter((e) => e && (e.degree || e.institution));
  const validCertifications = (certifications || []).filter((c) => c && c.name);
  const validExperience = (experience || []).filter((e) => e && (e.role || e.company));
  const validProjects = (projects || []).filter((p) => p && (p.name || p.description));

  const allSkillsList = [
    ...techSkills.map((name) => ({ name, type: 'tech' })),
    ...softSkills.map((name) => ({ name, type: 'soft' })),
  ];

  // Distribute skills between Page 1 sidebar and Page 2 continuation if skill list exceeds available sidebar height
  let currentSidebarHeight = 0;
  const sidebarSkills = [];
  const overflowSkills = [];

  allSkillsList.forEach((skill) => {
    const itemHeight = skill.name.length > 50 ? 46 : skill.name.length > 25 ? 32 : 18;
    const gap = 4;
    if (currentSidebarHeight + itemHeight + gap <= 860) {
      sidebarSkills.push(skill);
      currentSidebarHeight += itemHeight + gap;
    } else {
      overflowSkills.push(skill);
    }
  });

  const typo = getTemplateTypography('executive-corporate');
  const sectionTitleStyle = {
    fontSize: typo.sectionTitle,
    marginBottom: '6px',
    paddingBottom: '3px',
    fontFamily: "Georgia, 'Times New Roman', serif",
  };

  // ── Header (Page 1 ONLY) ────────────────────────────────────────────────────
  const header = (
    <div
      style={{
        background: primaryColor,
        color: '#ffffff',
        padding: '16px 24px 14px',
        borderBottom: `3.5px solid ${accentColor}`,
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        flexShrink: 0,
        boxSizing: 'border-box',
        width: '100%',
        gap: '16px',
        fontFamily: "Georgia, 'Times New Roman', serif",
      }}
    >
      <div style={{ minWidth: 0, flex: 1 }}>
        <h1
          style={{
            fontSize: typo.name,
            fontWeight: 'bold',
            letterSpacing: '0.8px',
            textTransform: 'uppercase',
            margin: 0,
            color: '#ffffff',
            lineHeight: 1.15,
            overflowWrap: 'anywhere',
          }}
        >
          {personalInfo.fullName || (isPreview ? 'Executive Candidate' : 'Your Name')}
        </h1>
        {(personalInfo.targetRole || isPreview) && (
          <h2
            style={{
              fontSize: typo.targetRole,
              fontStyle: 'italic',
              color: '#fef3c7',
              letterSpacing: '0.8px',
              marginTop: '3px',
              margin: '3px 0 0 0',
              overflowWrap: 'anywhere',
            }}
          >
            {personalInfo.targetRole || 'Chief Executive Officer / Vice President'}
          </h2>
        )}
      </div>
      <ContactList
        personalInfo={personalInfo}
        align="right"
        accentColor="#fbbf24"
        textColor="#e2e8f0"
        style={{ fontSize: typo.contact }}
      />
    </div>
  );

  // ── Sidebar Sections (Left Sidebar — All Skills & Competencies) ────────────
  const sidebarSections = [];

  if (sidebarSkills.length > 0) {
    sidebarSections.push({
      id: 'executive-skills',
      type: 'skills',
      render: () => (
        <div style={{ width: '100%', boxSizing: 'border-box' }}>
          <SectionTitle
            title="Technical Skills & Competencies"
            icon={HiUserGroup}
            primaryColor={primaryColor}
            accentColor={accentColor}
            style={sectionTitleStyle}
          />
          <div
            style={{
              display: 'flex',
              flexDirection: 'column',
              gap: '4px',
              fontSize: typo.technicalSkills,
              color: '#334155',
              width: '100%',
              boxSizing: 'border-box',
            }}
          >
            {sidebarSkills.map((sk, i) => (
              <div
                key={`side-sk-${i}`}
                style={{
                  display: 'flex',
                  alignItems: 'flex-start',
                  gap: '6px',
                  width: '100%',
                  boxSizing: 'border-box',
                  minWidth: 0,
                }}
              >
                <span
                  style={{
                    width: '4px',
                    height: '4px',
                    borderRadius: '50%',
                    background: sk.type === 'tech' ? accentColor : primaryColor,
                    display: 'inline-block',
                    flexShrink: 0,
                    marginTop: '5px',
                  }}
                />
                <span
                  style={{
                    overflowWrap: 'anywhere',
                    wordBreak: 'break-word',
                    lineHeight: 1.35,
                    flex: 1,
                    minWidth: 0,
                    boxSizing: 'border-box',
                  }}
                >
                  {sk.name}
                </span>
              </div>
            ))}
          </div>
        </div>
      ),
    });
  }

  // ── Main Content Blocks ───────────────────────────────────────────────────
  const blocks = [];

  // 1. Executive Summary
  if (summary && summary.trim()) {
    blocks.push({
      id: 'summary',
      type: 'summary',
      render: () => (
        <SummaryCard
          text={summary}
          borderColor={accentColor}
          backgroundColor="#fcfcfd"
          textColor="#334155"
          style={{
            fontStyle: 'italic',
            borderLeftColor: accentColor,
            fontSize: typo.summary,
            lineHeight: 1.55,
          }}
        />
      ),
    });
  }

  // 2. Education (Immediately after Summary)
  if (validEducation.length > 0) {
    blocks.push({
      id: 'education',
      type: 'education',
      render: ({ isFirstOfThisSectionOnPage, sectionStartedOnPrevPage }) => (
        <div>
          <SectionTitle
            title={!sectionStartedOnPrevPage ? 'Education' : 'Education (Continued)'}
            icon={HiAcademicCap}
            primaryColor={primaryColor}
            accentColor={accentColor}
            style={sectionTitleStyle}
          />
          <div style={{ display: 'flex', flexDirection: 'column', gap: '7px' }}>
            {validEducation.map((edu, idx) => (
              <EducationItem
                key={idx}
                degree={edu.degree}
                field={edu.field}
                institution={edu.institution}
                startDate={edu.startDate}
                endDate={edu.endDate}
                gpa={edu.gpa}
                accentColor={accentColor}
              />
            ))}
          </div>
        </div>
      ),
    });
  }

  // 2. Leadership Experience
  if (validExperience.length > 0) {
    validExperience.forEach((exp, idx) => {
      blocks.push({
        id: `experience-${idx}`,
        type: 'experience',
        render: ({ isFirstOfThisSectionOnPage, sectionStartedOnPrevPage }) => (
          <div>
            {(idx === 0 || isFirstOfThisSectionOnPage) && (
              <SectionTitle
                title={idx === 0 || !sectionStartedOnPrevPage ? 'Executive Leadership Experience' : 'Executive Leadership Experience (Continued)'}
                icon={HiBriefcase}
                primaryColor={primaryColor}
                accentColor={accentColor}
                style={sectionTitleStyle}
              />
            )}
            <ExperienceItem
              role={exp.role}
              company={exp.company}
              startDate={exp.startDate}
              endDate={exp.endDate}
              current={exp.current}
              bullets={exp.bullets}
              accentColor={accentColor}
              dateBadge={true}
            />
          </div>
        ),
      });
    });
  }

  // 3. Strategic Initiatives (Projects)
  if (validProjects.length > 0) {
    validProjects.forEach((proj, idx) => {
      blocks.push({
        id: `initiative-${idx}`,
        type: 'projects',
        render: ({ isFirstOfThisSectionOnPage, sectionStartedOnPrevPage }) => (
          <div>
            {(idx === 0 || isFirstOfThisSectionOnPage) && (
              <SectionTitle
                title={idx === 0 || !sectionStartedOnPrevPage ? 'Strategic Initiatives & Key Portfolios' : 'Strategic Initiatives (Continued)'}
                icon={HiFolder}
                primaryColor={primaryColor}
                accentColor={accentColor}
                style={sectionTitleStyle}
              />
            )}
            <ProjectCard
              name={proj.name}
              description={proj.description}
              technologies={proj.technologies}
              link={proj.link}
              startDate={proj.startDate}
              endDate={proj.endDate}
              date={proj.date}
              bullets={proj.bullets}
              accentColor={accentColor}
              cardBg="#fcfcfd"
              borderColor="#e2e8f0"
              style={{
                borderLeft: `3px solid ${primaryColor}`,
                padding: '7px 10px',
              }}
            />
          </div>
        ),
      });
    });
  }

  // 4. Technical Skills (Continued) — Only if skill list exceeded Page 1 sidebar height
  if (overflowSkills.length > 0) {
    blocks.push({
      id: 'overflow-skills',
      type: 'skills',
      render: () => (
        <div>
          <SectionTitle
            title="Technical Skills (Continued)"
            icon={HiUserGroup}
            primaryColor={primaryColor}
            accentColor={accentColor}
            style={sectionTitleStyle}
          />
          <div
            style={{
              display: 'flex',
              flexWrap: 'wrap',
              gap: '6px 8px',
              fontSize: typo.technicalSkills,
              color: '#334155',
              lineHeight: 1.4,
            }}
          >
            {overflowSkills.map((sk, idx) => (
              <span
                key={idx}
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: '5px',
                  padding: '3px 8px',
                  backgroundColor: '#f8fafc',
                  border: '1px solid #e2e8f0',
                  borderRadius: '3px',
                  fontSize: typo.technicalSkills,
                  color: '#1e293b',
                  overflowWrap: 'anywhere',
                  wordBreak: 'break-word',
                  boxSizing: 'border-box',
                }}
              >
                <span
                  style={{
                    width: '4px',
                    height: '4px',
                    borderRadius: '50%',
                    background: sk.type === 'tech' ? accentColor : primaryColor,
                    flexShrink: 0,
                  }}
                />
                {sk.name}
              </span>
            ))}
          </div>
        </div>
      ),
    });
  }

  // 5. Credentials & Honors (Certifications — Main Content)
  if (validCertifications.length > 0) {
    blocks.push({
      id: 'certifications',
      type: 'certifications',
      render: ({ isFirstOfThisSectionOnPage, sectionStartedOnPrevPage }) => (
        <div>
          <SectionTitle
            title={!sectionStartedOnPrevPage ? 'Credentials & Honors' : 'Credentials & Honors (Continued)'}
            icon={HiSparkles}
            primaryColor={primaryColor}
            accentColor={accentColor}
            style={sectionTitleStyle}
          />
          <div style={{ display: 'flex', flexDirection: 'column', gap: '5px', fontSize: typo.certification, color: '#334155' }}>
            {validCertifications.map((cert, idx) => (
              <div key={idx} style={{ breakInside: 'avoid', pageBreakInside: 'avoid' }}>
                <div style={{ fontWeight: 700, color: '#0f172a', overflowWrap: 'anywhere' }}>{cert.name}</div>
                {cert.issuer && (
                  <div style={{ color: '#64748b', fontSize: '9.8px', overflowWrap: 'anywhere' }}>
                    {cert.issuer} {cert.date && `(${cert.date})`}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      ),
    });
  }

  // 6. Languages (Main Content)
  if (languages.length > 0) {
    blocks.push({
      id: 'languages',
      type: 'languages',
      render: ({ isFirstOfThisSectionOnPage, sectionStartedOnPrevPage }) => (
        <div>
          <SectionTitle
            title={!sectionStartedOnPrevPage ? 'Languages' : 'Languages (Continued)'}
            icon={HiLanguage}
            primaryColor={primaryColor}
            accentColor={accentColor}
            style={sectionTitleStyle}
          />
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: '6px 16px', fontSize: typo.language, color: '#334155' }}>
            {languages.map((lang, idx) => (
              <div key={idx} style={{ display: 'flex', alignItems: 'center', gap: '6px', overflowWrap: 'anywhere' }}>
                <span style={{ width: '4px', height: '4px', borderRadius: '50%', background: accentColor, display: 'inline-block', flexShrink: 0 }} />
                <span>{lang}</span>
              </div>
            ))}
          </div>
        </div>
      ),
    });
  }

  return (
    <TwoPageResumeCanvas
      header={header}
      sidebarSections={sidebarSections}
      page2Header={
        <PageRunningHeader
          fullName={personalInfo.fullName}
          targetRole={personalInfo.targetRole}
          primaryColor={primaryColor}
          pageNum={2}
          fontFamily="Georgia, 'Times New Roman', serif"
        />
      }
      blocks={blocks}
      fontFamily="Georgia, 'Times New Roman', serif"
      sidebarWidth="238px"
      lockSidebarWidth={true}
      sidebarBackground="#f8fafc"
      sidebarBorder="1px solid #e2e8f0"
      sidebarPadding="12px 10px"
      mainPadding="12px 16px"
      page2Padding="16px 22px"
      twoColumnGap={10}
      blockGap={8}
    />
  );
}

export default ExecutiveCorporateTemplate;
